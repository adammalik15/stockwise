'use client';
import { useState, useEffect } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip } from 'recharts';
import type { PricePoint } from '@/types';

type Period = '1d' | '1mo' | '3mo' | '6mo' | '1y' | '2y';

function formatXTick(dateStr: string, period: Period) {
  const d = new Date(dateStr);
  if (period === '1d') {
    return d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
  }
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function formatTooltipDate(dateStr: string, period: Period) {
  const d = new Date(dateStr);
  if (period === '1d') {
    return d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  }
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: period === '2y' ? 'numeric' : undefined });
}

export default function PriceChart({ ticker, initialData, currentPrice }: {
  ticker: string;
  initialData: PricePoint[];
  currentPrice: number;
}) {
  const [period, setPeriod] = useState<Period>('6mo');
  const [data, setData] = useState(initialData);
  const [loading, setLoading] = useState(false);
  const [width, setWidth] = useState(600);

  useEffect(() => {
    function updateWidth() {
      const container = document.getElementById('chart-container');
      if (container) setWidth(container.offsetWidth);
    }
    updateWidth();
    window.addEventListener('resize', updateWidth);
    return () => window.removeEventListener('resize', updateWidth);
  }, []);

  async function changePeriod(p: Period) {
    if (p === period) return;
    setPeriod(p);
    setLoading(true);
    try {
      const res = await fetch('/api/stocks/' + ticker + '/history?period=' + p);
      const json = await res.json();
      setData(json.history ?? []);
    } finally {
      setLoading(false);
    }
  }

  const startPrice = data[0]?.close ?? currentPrice;
  const isPos = currentPrice >= startPrice;
  const stroke = isPos ? '#00d4aa' : '#ff4d6d';

  const Tip = ({ active, payload }: any) => {
    if (!active || !payload?.[0]) return null;
    const d = payload[0].payload;
    return (
      <div className="bg-surface-2 border border-border rounded-lg px-3 py-2 text-xs">
        <p className="text-secondary mb-1">{formatTooltipDate(d.date, period)}</p>
        <p className="font-mono font-semibold text-white">${d.close?.toFixed(2)}</p>
      </div>
    );
  };

  return (
    <div>
      <div className="flex gap-1 mb-4">
        {(['1d', '1mo', '3mo', '6mo', '1y', '2y'] as Period[]).map(p => (
          <button key={p} onClick={() => changePeriod(p)}
            className={'px-3 py-1 rounded-lg text-xs font-medium transition-all ' +
              (period === p
                ? 'bg-accent-green/15 text-accent-green'
                : 'text-secondary hover:text-white hover:bg-surface-2'
              )}>
            {p}
          </button>
        ))}
      </div>

      <div id="chart-container" className="w-full" style={{ height: '200px', position: 'relative' }}>
        {loading && (
          <div className="absolute inset-0 flex items-center justify-center bg-surface-1/60 z-10 rounded-lg">
            <div className="w-5 h-5 border-2 border-accent-green/30 border-t-accent-green rounded-full animate-spin" />
          </div>
        )}
        {data.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <p className="text-sm text-muted">No chart data available</p>
          </div>
        ) : (
          <AreaChart width={width} height={200} data={data} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
            <defs>
              <linearGradient id="pg" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={stroke} stopOpacity={0.15} />
                <stop offset="100%" stopColor={stroke} stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis
              dataKey="date"
              tickFormatter={d => formatXTick(d, period)}
              tick={{ fill: '#6b6b7e', fontSize: 10 }}
              axisLine={false} tickLine={false}
              interval="preserveStartEnd"
            />
            <YAxis
              domain={['auto', 'auto']}
              tick={{ fill: '#6b6b7e', fontSize: 10 }}
              axisLine={false} tickLine={false}
              tickFormatter={v => '$' + v.toFixed(0)}
              width={55}
            />
            <Tooltip content={<Tip />} />
            <Area
              type="monotone" dataKey="close"
              stroke={stroke} strokeWidth={2}
              fill="url(#pg)" dot={false}
              activeDot={{ r: 4, fill: stroke, strokeWidth: 0 }}
            />
          </AreaChart>
        )}
      </div>
    </div>
  );
}
