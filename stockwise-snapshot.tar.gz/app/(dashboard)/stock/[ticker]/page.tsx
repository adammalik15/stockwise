import { fetchStockData, fetchPriceHistory } from '@/services/yahoo-finance';
import { formatMarketCap, formatPrice, formatPercent } from '@/lib/utils';
import { createClient } from '@/lib/supabase/server';
import PriceChart from '@/components/charts/PriceChart';
import RecommendationPanel from '@/components/stock/RecommendationPanel';
import NewsPanel from '@/components/stock/NewsPanel';
import AddStockButtons from '@/components/stock/AddStockButtons';
import HalalBadge from '@/components/stock/HalalBadge';
import ShareholdersPanel from '@/components/stock/ShareholdersPanel';
import FundamentalsPanel from '@/components/stock/FundamentalsPanel';
import { screenStock } from '@/services/halal-screener';
import { TrendingUp, TrendingDown } from 'lucide-react';
import PortfolioPositionPanel from '@/components/stock/PortfolioPositionPanel';
import ShortTermPanel from '@/components/stock/ShortTermPanel';

export const dynamic = 'force-dynamic';

export default async function StockDetailPage({
  params,
}: {
  params: Promise<{ ticker: string }>;
}) {
  const { ticker } = await params;
  const upper = ticker.toUpperCase();

  const [stock, history] = await Promise.all([
    fetchStockData(upper),
    fetchPriceHistory(upper, '6mo'),
  ]);

  if (!stock) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center gap-4 px-4">
        <p className="text-2xl">⚠️</p>
        <h2 className="text-xl font-semibold text-white">Could not load {upper}</h2>
        <p className="text-secondary text-sm max-w-sm">
          Market data is temporarily unavailable. Please try again in a moment.
        </p>
      </div>
    );
  }

  const isPos = (stock.change_percent ?? 0) >= 0;
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const [{ data: inP }, { data: inW }] = await Promise.all([
    supabase
      .from('portfolios')
      .select('id, term')
      .eq('user_id', user!.id)
      .eq('ticker', upper)
      .maybeSingle(),
    supabase
      .from('watchlists')
      .select('id')
      .eq('user_id', user!.id)
      .eq('ticker', upper)
      .maybeSingle(),
  ]);

  const fiftyTwoPct =
    stock.fifty_two_week_high && stock.fifty_two_week_low
      ? ((stock.price - stock.fifty_two_week_low) /
          (stock.fifty_two_week_high - stock.fifty_two_week_low)) *
        100
      : null;

  const halalResult = screenStock(stock);

  return (
    <div className="space-y-4 page-enter">

      {/* ── Stock Header ── */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-surface-2 border border-border flex items-center justify-center shrink-0">
            <span className="font-mono font-bold text-accent-green text-base sm:text-lg">
              {upper.slice(0, 2)}
            </span>
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-white">{upper}</h1>
            <p className="text-secondary text-sm">{stock.name}</p>
            {stock.sector && (
              <div className="flex flex-wrap gap-1.5 mt-1.5">
                <span className="badge-neutral text-[10px]">{stock.sector}</span>
                {stock.industry && stock.industry !== stock.sector && (
                  <span className="badge-neutral text-[10px]">{stock.industry}</span>
                )}
              </div>
            )}
          </div>
        </div>
        <div className="sm:shrink-0">
          <AddStockButtons ticker={upper} inPortfolio={!!inP} inWatchlist={!!inW} />
        </div>
      </div>

      {/* ── Price Card + Chart ── */}
      <div className="card">
        <div className="flex flex-wrap items-end gap-3 mb-1">
          <span className="text-3xl sm:text-4xl font-mono font-bold text-white">
            {formatPrice(stock.price)}
          </span>
          <div
            className={`flex items-center gap-1.5 mb-0.5 ${
              isPos ? 'text-accent-green' : 'text-accent-red'
            }`}
          >
            {isPos ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
            <span className="font-mono font-semibold text-sm sm:text-base">
              {formatPercent(stock.change_percent)}
            </span>
            <span className="text-xs sm:text-sm">
              ({formatPrice(stock.change)} today)
            </span>
          </div>
        </div>
        <p className="text-[11px] text-muted mb-4">
          Prices delayed ~15 min · Data via Finnhub
        </p>
        <PriceChart
          ticker={upper}
          initialData={history}
          currentPrice={stock.price}
        />
      </div>

      {/* ── Portfolio position + transaction history (only shown if user holds the stock) ── */}
      {inP && <PortfolioPositionPanel ticker={upper} currentPrice={stock.price} />}

      {/* ── Short-term indicators (only for short-term holdings) ── */}
      {inP?.term === 'short' && <ShortTermPanel ticker={upper} currentPrice={stock.price} />}

      {/* ── HALAL BADGE — right after chart, most important for Muslim investors ── */}
      <HalalBadge result={halalResult} ticker={upper} />

      {/* ── Key Stats ── */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3">
        {[
          { label: 'Market Cap', value: formatMarketCap(stock.market_cap) },
          {
            label: 'P/E Ratio',
            value: stock.pe_ratio ? stock.pe_ratio.toFixed(1) : 'N/A',
          },
          {
            label: 'Beta',
            value: stock.beta ? stock.beta.toFixed(2) : 'N/A',
          },
          {
            label: 'Dividend Yield',
            value: stock.dividend_yield
              ? (stock.dividend_yield * 100).toFixed(2) + '%'
              : 'None',
          },
        ].map(s => (
          <div key={s.label} className="card p-3 sm:p-5">
            <p className="label mb-1.5 text-[10px] sm:text-xs">{s.label}</p>
            <p className="font-mono text-sm sm:text-base font-semibold text-white">
              {s.value}
            </p>
          </div>
        ))}
      </div>

      {/* ── 52-Week Range ── */}
      {fiftyTwoPct !== null && (
        <div className="card">
          <p className="label mb-3">52-Week Range</p>
          <div className="flex justify-between text-xs text-secondary mb-2">
            <span>Low: {formatPrice(stock.fifty_two_week_low)}</span>
            <span className="font-mono font-semibold text-white">
              {formatPrice(stock.price)}
            </span>
            <span>High: {formatPrice(stock.fifty_two_week_high)}</span>
          </div>
          <div className="h-2 bg-surface-3 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-accent-red via-accent-yellow to-accent-green rounded-full transition-all"
              style={{
                width: Math.min(100, Math.max(0, fiftyTwoPct)) + '%',
              }}
            />
          </div>
          <p className="text-xs text-secondary mt-2">
            Currently at {fiftyTwoPct.toFixed(0)}% of 52-week range
          </p>
        </div>
      )}

      {/* ── Volume + Last Updated ── */}
      <div className="grid grid-cols-2 gap-2 sm:gap-3">
        <div className="card p-3 sm:p-5">
          <p className="label mb-1.5">Volume</p>
          <p className="font-mono text-sm font-semibold text-white">
            {stock.volume ? (stock.volume / 1e6).toFixed(2) + 'M' : 'N/A'}
          </p>
        </div>
        <div className="card p-3 sm:p-5">
          <p className="label mb-1.5">Last Updated</p>
          <p className="font-mono text-sm font-semibold text-white">
            {new Date(stock.last_updated).toLocaleTimeString([], {
              hour: '2-digit',
              minute: '2-digit',
            })}
          </p>
        </div>
      </div>

      {/* ── About ── */}
      {stock.description && (
        <div className="card">
          <p className="label mb-3">About {stock.name}</p>
          <p className="text-sm text-secondary leading-relaxed line-clamp-4">
            {stock.description}
          </p>
        </div>
      )}

      {/* ── Fundamental Analysis ── */}
      <FundamentalsPanel ticker={upper} />

      {/* ── AI Recommendation ── */}
      <RecommendationPanel ticker={upper} />

      {/* ── News & Sentiment ── */}
      <NewsPanel ticker={upper} />

      {/* ── Insider Transactions ── */}
      <ShareholdersPanel ticker={upper} />

    </div>
  );
}
